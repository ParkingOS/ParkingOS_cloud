1.导入新的数据库,从备份文件恢复v2.0pg.dump
2.db.properties配置待升级的数据库和新的数据库
3.执行jar包(java -jar DataBaseDispatcher.jar)
4.自动执行添加新表、现有表增加字段
5.如失败条数为0则更新成功